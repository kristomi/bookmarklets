// Auto-generated script metadata
window.SCRIPT_METADATA = {
  "kindle-highlights": {
    "name": "Kindle Highlights",
    "category": "Scrapers",
    "description": "Extract highlights from Kindle notebook",
    "filename": "kindle-highlights.js",
    "scriptFile": "script_kindle_highlights.js"
  },
  "substack-export": {
    "name": "Substack Article Export",
    "category": "Scrapers",
    "description": "Extract Substack articles as markdown",
    "filename": "substack.js",
    "scriptFile": "script_substack_export.js"
  },
  "webpage-export": {
    "name": "Webpage Export",
    "category": "Scrapers",
    "description": "Extract any webpage as markdown, with optional API posting",
    "filename": "webpage.js",
    "scriptFile": "script_webpage_export.js"
  },
  "claude-export": {
    "name": "Claude Export",
    "category": "LLMs",
    "description": "Export Claude conversation as markdown",
    "filename": "claude.js",
    "scriptFile": "script_claude_export.js"
  },
  "chatgpt-export": {
    "name": "ChatGPT Export",
    "category": "LLMs",
    "description": "Export ChatGPT conversation as markdown",
    "filename": "chatgpt.js",
    "scriptFile": "script_chatgpt_export.js"
  }
};
