// Auto-generated script metadata
window.SCRIPT_METADATA = {
  "kindle-highlights": {
    "name": "Kindle Highlights",
    "category": "Scrapers",
    "description": "Extract highlights from Kindle notebook",
    "filename": "kindle-highlights.js",
    "scriptFile": "script_kindle_highlights.js"
  },
  "substack-export": {
    "name": "Substack Article Export",
    "category": "Scrapers",
    "description": "Extract Substack articles as markdown",
    "filename": "substack.js",
    "scriptFile": "script_substack_export.js"
  },
  "substack-audio-export": {
    "name": "Substack Audio Export",
    "category": "Scrapers",
    "description": "Find podcast, voiceover and video files behind a Substack post",
    "filename": "substack-audio.js",
    "scriptFile": "script_substack_audio_export.js"
  },
  "webpage-export": {
    "name": "Webpage Export",
    "category": "Scrapers",
    "description": "Extract any webpage as markdown, with optional API posting",
    "filename": "webpage.js",
    "scriptFile": "script_webpage_export.js"
  },
  "cookies-export": {
    "name": "Cookies Export",
    "category": "Scrapers",
    "description": "Export cookies for a chosen URL as a cookies.txt file",
    "filename": "cookies.js",
    "scriptFile": "script_cookies_export.js"
  },
  "claude-export": {
    "name": "Claude Export",
    "category": "LLMs",
    "description": "Export Claude conversation as markdown",
    "filename": "claude.js",
    "scriptFile": "script_claude_export.js"
  },
  "chatgpt-export": {
    "name": "ChatGPT Export",
    "category": "LLMs",
    "description": "Export ChatGPT conversation as markdown",
    "filename": "chatgpt.js",
    "scriptFile": "script_chatgpt_export.js"
  }
};
