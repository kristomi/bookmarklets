// Simplified popup script for bundled extension
class ScriptManager {
    constructor() {
        this.config = {
    "title": "Kristomi's Bookmarklets",
    "description": "Select a script to run on this page",
    "version": "1.5.0",
    "updated": "2026-08-12",
    "theme": {
        "colors": {
            "primary": "#667eea",
            "secondary": "#764ba2",
            "background": "#ffffff",
            "overlay": "rgba(0, 0, 0, 0.8)",
            "border": "#e5e7eb",
            "text": "#374151",
            "textLight": "#6b7280",
            "buttonHover": "#f3f4f6",
            "buttonHoverBorder": "#9ca3af",
            "categoryText": "#374151",
            "success": "#10b981",
            "successHover": "#059669"
        },
        "fonts": {
            "primary": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
            "mono": "'Courier New', monospace"
        },
        "spacing": {
            "containerPadding": "30px",
            "headerPadding": "24px 24px 16px",
            "contentPadding": "20px 24px",
            "footerPadding": "16px 24px",
            "buttonPadding": "14px 16px",
            "borderRadius": "12px",
            "buttonRadius": "8px"
        },
        "shadows": {
            "menu": "0 20px 60px rgba(0, 0, 0, 0.3)",
            "button": "0 2px 8px rgba(0, 0, 0, 0.1)"
        },
        "animations": {
            "menuSlideIn": "menuSlideIn 0.3s ease-out",
            "buttonTransition": "all 0.2s ease"
        }
    },
    "ui": {
        "maxWidth": "450px",
        "maxHeight": "80vh",
        "loadingText": "⏳ Loading scripts...",
        "cancelText": "Cancel",
        "errorPrefix": "Error loading script:",
        "successPrefix": "Successfully loaded script:",
        "blurEffect": true,
        "showVersion": true,
        "showCloseOnEscape": true,
        "showClickOutsideToClose": true
    },
    "scripts": {
        "kindle-highlights": {
            "name": "Kindle Highlights",
            "category": "Scrapers",
            "description": "Extract highlights from Kindle notebook"
        },
        "substack-export": {
            "name": "Substack Article Export",
            "category": "Scrapers",
            "description": "Extract Substack articles as markdown"
        },
        "substack-audio-export": {
            "name": "Substack Audio Export",
            "category": "Scrapers",
            "description": "Find podcast, voiceover and video files behind a Substack post"
        },
        "webpage-export": {
            "name": "Webpage Export",
            "category": "Scrapers",
            "description": "Extract any webpage as markdown, with optional API posting"
        },
        "cookies-export": {
            "name": "Cookies Export",
            "category": "Scrapers",
            "description": "Export cookies for a chosen URL as a cookies.txt file"
        },
        "claude-export": {
            "name": "Claude Export",
            "category": "LLMs",
            "description": "Export Claude conversation as markdown"
        },
        "chatgpt-export": {
            "name": "ChatGPT Export",
            "category": "LLMs",
            "description": "Export ChatGPT conversation as markdown"
        }
    }
};
        this.scripts = {
    "kindle-highlights": {
        "name": "Kindle Highlights",
        "category": "Scrapers",
        "description": "Extract highlights from Kindle notebook",
        "filename": "kindle-highlights.js",
        "scriptFile": "script_kindle_highlights.js"
    },
    "substack-export": {
        "name": "Substack Article Export",
        "category": "Scrapers",
        "description": "Extract Substack articles as markdown",
        "filename": "substack.js",
        "scriptFile": "script_substack_export.js"
    },
    "substack-audio-export": {
        "name": "Substack Audio Export",
        "category": "Scrapers",
        "description": "Find podcast, voiceover and video files behind a Substack post",
        "filename": "substack-audio.js",
        "scriptFile": "script_substack_audio_export.js"
    },
    "webpage-export": {
        "name": "Webpage Export",
        "category": "Scrapers",
        "description": "Extract any webpage as markdown, with optional API posting",
        "filename": "webpage.js",
        "scriptFile": "script_webpage_export.js"
    },
    "cookies-export": {
        "name": "Cookies Export",
        "category": "Scrapers",
        "description": "Export cookies for a chosen URL as a cookies.txt file",
        "filename": "cookies.js",
        "scriptFile": "script_cookies_export.js"
    },
    "claude-export": {
        "name": "Claude Export",
        "category": "LLMs",
        "description": "Export Claude conversation as markdown",
        "filename": "claude.js",
        "scriptFile": "script_claude_export.js"
    },
    "chatgpt-export": {
        "name": "ChatGPT Export",
        "category": "LLMs",
        "description": "Export ChatGPT conversation as markdown",
        "filename": "chatgpt.js",
        "scriptFile": "script_chatgpt_export.js"
    }
};
        this.currentTab = null;
        this.init();
    }
    
    async init() {
        await this.getCurrentTab();
        this.updateUI();
        this.showStatus('Ready', 'success');
    }
    
    async getCurrentTab() {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        this.currentTab = tab;
        
        const siteInfo = document.getElementById('current-site');
        if (tab) {
            const domain = new URL(tab.url).hostname;
            siteInfo.textContent = `Current site: ${domain}`;
        }
    }
    
    updateUI() {
        const container = document.getElementById('scripts-container');
        container.innerHTML = '';
        
        // Group scripts by category
        const categories = {};
        for (const [scriptId, script] of Object.entries(this.scripts)) {
            const category = script.category || 'Other';
            if (!categories[category]) {
                categories[category] = [];
            }
            categories[category].push({ id: scriptId, ...script });
        }
        
        // Render categories
        for (const [categoryName, scripts] of Object.entries(categories)) {
            const categoryDiv = document.createElement('div');
            categoryDiv.className = 'category';
            
            const titleDiv = document.createElement('div');
            titleDiv.className = 'category-title';
            titleDiv.textContent = categoryName;
            categoryDiv.appendChild(titleDiv);
            
            scripts.forEach(script => {
                const button = this.createScriptButton(script);
                categoryDiv.appendChild(button);
            });
            
            container.appendChild(categoryDiv);
        }
    }
    
    createScriptButton(script) {
        const button = document.createElement('button');
        button.className = 'script-button';
        
        const isCompatible = this.isScriptCompatible(script);
        button.disabled = !isCompatible;
        
        button.innerHTML = `
            <div class="script-name">${script.name}</div>
            <div class="script-description">${script.description}</div>
        `;
        
        if (isCompatible) {
            button.addEventListener('click', () => this.runScript(script));
        }
        
        return button;
    }
    
    isScriptCompatible(script) {
        // Allow all scripts to run on any site
        return true;
    }
    
    async runScript(script) {
        try {
            this.showStatus(`Running ${script.name}...`, 'info');
            
            const results = await chrome.scripting.executeScript({
                target: { tabId: this.currentTab.id },
                files: [script.scriptFile]
            });
            
            this.showStatus(`${script.name} executed successfully`, 'success');
            
            // Close popup after a delay
            setTimeout(() => {
                window.close();
            }, 1500);
            
        } catch (error) {
            console.error('Script execution failed:', error);
            this.showStatus(`Error running ${script.name}: ${error.message}`, 'error');
        }
    }
    
    showStatus(message, type = 'info') {
        const statusElement = document.getElementById('status');
        statusElement.textContent = message;
        statusElement.className = `status ${type}`;
        statusElement.style.display = 'block';
        
        if (type === 'success' || type === 'error') {
            setTimeout(() => {
                statusElement.style.display = 'none';
            }, 3000);
        }
    }
}

// Initialize when popup loads
document.addEventListener('DOMContentLoaded', () => {
    new ScriptManager();
});